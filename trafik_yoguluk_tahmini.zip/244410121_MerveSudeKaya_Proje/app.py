import streamlit as st
import pandas as pd
import numpy as np
import joblib


st.set_page_config(page_title="Trafik Analiz Paneli", layout="wide", page_icon="🚦")


st.markdown("""
    <style>
    .main { background-color: #f8f9fa; }
    .stButton>button { width: 100%; border-radius: 20px; height: 3.5em; background-color: #ff4b4b; color: white; font-weight: bold; font-size: 18px; }
    .result-card { padding: 30px; border-radius: 15px; color: white; text-align: center; margin-bottom: 20px; }
    .success-card { background-color: #28a745; box-shadow: 0 4px 15px rgba(40,167,69,0.3); }
    .error-card { background-color: #dc3545; box-shadow: 0 4px 15px rgba(220,53,69,0.3); }
    
    /* Senin istediğin özel renkli kartlar :) */
    .metric-card { padding: 20px; border-radius: 15px; text-align: center; box-shadow: 2px 2px 10px rgba(0,0,0,0.05); margin-bottom: 10px; }
    .saat-card { background-color: #FFD1DC; border: 1px solid #FFB6C1; } /* Açık Pembe */
    .gun-card { background-color: #E6E6FA; border: 1px solid #D8BFD8; }  /* Açık Mor */
    .hava-card { background-color: #ADD8E6; border: 1px solid #87CEEB; } /* Açık Mavi */
    
    .metric-card h2 { margin: 10px 0 0 0; font-size: 32px; font-weight: bold; }
    </style>
    """, unsafe_allow_html=True)


@st.cache_resource
def load_assets():
    try:
       
        model = joblib.load('best_model.pkl') 
        scaler = joblib.load('scaler.pkl')
        return model, scaler
    except:
        return None, None

model, scaler = load_assets()
if model is None:
    st.error("🚨 Model dosyaları bulunamadı! Lütfen best_model.pkl ve scaler.pkl dosyalarını kontrol et.")
    st.stop()


model_features = list(scaler.feature_names_in_)

st.title("🚦 Akıllı Trafik Tahmin & Dinamik Analiz Paneli")


col_in, col_res = st.columns([1, 1.3], gap="large")

with col_in:
    st.subheader("📍 Durum Parametreleri")
    with st.container(border=True):
        saat = st.slider("Saat Seçimi", 0, 23, 17)
        gun = st.selectbox("Haftanın Günü", ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"], index=3)
        tatil = st.toggle("📅 Resmi Tatil mi?")
    
    with st.container(border=True):
        temp_c = st.number_input("Hava Sıcaklığı (°C)", value=13.0)
        gokyuzu = st.selectbox("Gökyüzü Durumu", ["Açık", "Bulutlu", "Yağmurlu", "Karlı", "Sisli"], index=1)
        rain_label = st.select_slider("Yağmur Şiddeti", ["Yok", "Hafif", "Orta", "Şiddetli"])
        snow_label = st.select_slider("Kar Şiddeti", ["Yok", "Hafif", "Yoğun"])


with col_res:
    st.subheader("📊 Tahmin Analizi")
    
    if st.button("🔎 TRAFİK DURUMUNU SORGULA"):
        
        input_df = pd.DataFrame(0, index=[0], columns=model_features)
        day_idx = {"Pazartesi":0, "Salı":1, "Çarşamba":2, "Perşembe":3, "Cuma":4, "Cumartesi":5, "Pazar":6}[gun]
        
        
        input_df['temp'] = temp_c + 273.15 
        input_df['hour'] = saat
        input_df['day_of_week'] = day_idx
        input_df['is_holiday'] = 1 if tatil else 0
        input_df['clouds_all'] = {"Açık":0, "Bulutlu":50, "Yağmurlu":90, "Karlı":90, "Sisli":100}[gokyuzu]
        input_df['rain_1h'] = {"Yok": 0.0, "Hafif": 2.0, "Orta": 10.0, "Şiddetli": 30.0}[rain_label]
        input_df['snow_1h'] = {"Yok": 0.0, "Hafif": 1.5, "Yoğun": 7.0}[snow_label]

        try:
            
            scaled = scaler.transform(input_df)
            prediction = model.predict(scaled)[0]
            probs = model.predict_proba(scaled)[0]
            prob_val = np.max(probs) * 100

            
            local_contribs = np.abs(scaled[0] * model.feature_importances_)
            
            s_val = local_contribs[model_features.index('hour')]
            g_val = local_contribs[model_features.index('day_of_week')] + (local_contribs[model_features.index('is_holiday')] if 'is_holiday' in model_features else 0)
            h_val = sum([local_contribs[i] for i, col in enumerate(model_features) if col in ['temp', 'rain_1h', 'snow_1h', 'clouds_all']])
            
            total = s_val + g_val + h_val + 1e-9
            saat_p, gun_p = round((s_val/total)*100), round((g_val/total)*100)
            hava_p = 100 - (saat_p + gun_p)

           
            status = "YOĞUN" if prediction == 1 else "AKICI"
            card_color = "error-card" if prediction == 1 else "success-card"
            
        
            st.markdown(f'<div class="result-card {card_color}"><h1>{status}</h1><h2>%{prob_val:.2f} Olasılıkla</h2></div>', unsafe_allow_html=True)
            st.progress(prob_val / 100)

           
            st.write("### 🧠 Bu Karar Nasıl Verildi? (Anlık Değişen Dinamik Etki)")
            m1, m2, m3 = st.columns(3)
            with m1:
                st.markdown(f'<div class="metric-card saat-card">Saat Etkisi<br><h2 style="color:#D81B60;">%{saat_p}</h2></div>', unsafe_allow_html=True)
            with m2:
                st.markdown(f'<div class="metric-card gun-card">Gün Etkisi<br><h2 style="color:#6A1B9A;">%{gun_p}</h2></div>', unsafe_allow_html=True)
            with m3:
                st.markdown(f'<div class="metric-card hava-card">Hava Etkisi<br><h2 style="color:#0277BD;">%{hava_p}</h2></div>', unsafe_allow_html=True)

        except Exception as e:
            st.error(f"Hata: {e}")
    else:
        st.info("👈 Değerleri belirledikten sonra sorgula butonuna basınız.")